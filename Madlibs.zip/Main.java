//David Lim
//8-18-22
//Project: learning concatenation

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main extends  JFrame implements ActionListener{

	//declare our components or fields
	// a field is a global level variable
	JTextField txtnoun = new JTextField(5);
  JTextField txtnoun0 = new JTextField(5);
  JTextField txtpronoun = new JTextField(5);
  JTextField txtnoun1 = new JTextField(5);
  JTextField txtadj = new JTextField(5);
  JTextField txtverb = new JTextField(5);
  JTextField txtpronoun0 = new JTextField(5);
  JTextField txtnoun2 = new JTextField(5);
  JTextField txtadj0 = new JTextField(5);
  JTextField txtpronoun1 = new JTextField(5);
  JTextField txtverb0 = new JTextField(5);
  JTextField txtending = new JTextField(5);
	
	//declare textArea
	JTextArea txamadlib = new JTextArea("",50,30);
	JButton btnAdd = new JButton("Add to List");
	
	//declare variables to hold information.
	String storyString;
	
	
	
	//main is the first method to run - method means function
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declare a frame for form
		Main frame = new Main();
		frame.setSize(500,500);
		frame.setVisible(true);

	}
	//declare constructor for the project
	//The constructor sets everything up.
	public Main() 
	{
		
		super("Button Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//set layout manager
		setLayout(new FlowLayout());
		//add our components to the form
		add(new JLabel("(noun)"));
    add(txtnoun);
    add(new JLabel("went to the (noun)"));
    add(txtnoun0);
    add(new JLabel("one day. When (name)"));
    add(txtpronoun);
    add(new JLabel("was there he/she saw a (noun)"));
    add(txtnoun1);
    add(new JLabel(". He/she was very (adj)"));
    add(txtadj);
    add(new JLabel("and decided to (verb)"));
    add(txtverb);
    add(new JLabel(". (name)"));
    add(txtpronoun0);
    add(new JLabel("got to the front of the (noun)"));
    add(txtnoun2);
    add(new JLabel(", but the door was (adjective)"));
    add(txtadj0);
    add(new JLabel(". (name)"));
    add(txtpronoun1);
    add(new JLabel("then decided to (verb)"));
    add(txtverb0);
    add(new JLabel(".(make your own ending)"));
    add(txtending);
    //LEFT OFF HERE
		add(btnAdd);
		add(txamadlib);
		//*********
		//add listener to the button
		btnAdd.addActionListener(this);
		
		
		
		
		
	}//end of constructor
	
	//when you push the button - the code comes here
	
	public void actionPerformed(ActionEvent event) 
	{
		Object objSource = event.getSource();
		
		if(objSource == btnAdd) 
		{
			
			String outputString = "";
			//get information from textboxes
			storyString = txtnoun.getText() + " went to the " + txtnoun0.getText() + " one day. When " + txtpronoun.getText() + "\n" + " was there he saw a " + txtnoun1.getText() + ". He was very " + txtadj.getText() + " and decided to " + "\n" + txtverb.getText() + ". " + txtpronoun0.getText() +" got to the front of the " + txtnoun2.getText() +", but the door was " + txtadj0.getText() + ". " +  "\n" + txtpronoun1.getText() + " then decided to " + txtverb0.getText() + ". " + txtending.getText();
			
			//concatenate the text together
			outputString = storyString + "\n";
			//output to the text area
			txamadlib.append(outputString);
			txtnoun.setText("");
		  txtnoun0.setText("");
      txtpronoun.setText("");
      txtnoun1.setText("");
      txtadj.setText("");
      txtverb.setText("");
      txtpronoun0.setText("");
      txtnoun2.setText("");
      txtadj0.setText("");
      txtpronoun1.setText("");
      txtverb0.setText("");
      txtending.setText("");
			//clear text boxes
			
			txtnoun.requestFocus();
		}
		
		
		
	}
	

}//end of class