//David Lim
//8-22-22
//Project: BMI

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main extends  JFrame implements ActionListener{

	//declare our components or fields
	// a field is a global level variable
	JTextField txtweight = new JTextField(5);
  JTextField txtfeet = new JTextField(5);
  JTextField txtinches = new JTextField(5);
  double totalbmi = 0;
	int personcount = 0;
	//declare textArea
	JTextArea txabmi = new JTextArea("Your BMI: " + "\n" + "Avg BMI: " + "\n" + "Total number of people: ",50,30);
	JButton btncalculate = new JButton("Calculate");
	
	//declare variables to hold information.
	String storyString;
	
	
	
	//main is the first method to run - method means function
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declare a frame for form
		Main frame = new Main();
		frame.setSize(200,200);
		frame.setVisible(true);

	}
	//declare constructor for the project
	//The constructor sets everything up.
	public Main() 
	{
		
		super("Button Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//set layout manager
		setLayout(new FlowLayout());
		//add our components to the form
    add(new JLabel("Enter weight:"));
		add(txtweight);
    add(new JLabel("Enter height in feet:"));
    add(txtfeet);
    add(new JLabel("Enter height in inches::"));
    add(txtinches);
		add(btncalculate);
		add(txabmi);
    txabmi.setEnabled(false);
		//*********
		//add listener to the button
		btncalculate.addActionListener(this);

		
		
		
		
	}//end of constructor
	
	//when you push the button - the code comes here
	
	public void actionPerformed(ActionEvent event) 
	{
		Object objSource = event.getSource();
		
		if(objSource == btncalculate) 
		{
      txabmi.setText("");
      personcount++;
			String outputString = "";
			//get information from textboxes
		  double pounds = Double.parseDouble(txtweight.getText());
      int feet = Integer.parseInt(txtfeet.getText());
      int inches = Integer.parseInt(txtinches.getText());

      double kilograms = pounds * 0.454;
      double meters = ((12 * feet) + inches) * 0.0254;
      double bmi = calculate(kilograms, meters);
      totalbmi += bmi;
			double avg = totalbmi / personcount;
			//concatenate the text together
			outputString = "Your BMI: " + bmi + "\n"
        + "Avg BMI: " + avg + "\n" + "Total number of people: " + personcount;
			//output to the text area
			txabmi.append(outputString);
			//clear text boxes
			txtweight.setText("");
      txtfeet.setText("");
      txtinches.setText("");
			txtweight.requestFocus();
		}
		
		
		
	}
	public double calculate(double weight, double height){
    double bmi = 0;
    bmi = weight / Math.pow(height, 2);
    return bmi;
  }

}//end of class