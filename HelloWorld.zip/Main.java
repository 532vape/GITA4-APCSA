//Name: David Lim
//Date: 8-16-22
//Project: Hello World
//This project creates a frame with labels

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

class Main extends JFrame{
  public static void main(String[] args) {

    JFrame.setDefaultLookAndFeelDecorated(true);
    //creating a frame object
    JFrame aFrame = new JFrame("First Frame");
    aFrame.setSize(200,200);
    aFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //Declare labels
    JLabel question = new JLabel("Hello World");
    JLabel question2  = new JLabel("Hello Too!");
    //declare our fonts
    Font headLineFont = new Font("Arial", Font.BOLD, 35);
    Font headLineFont2 = new Font("Arial", Font.BOLD, 20);

    question.setFont(headLineFont);
    aFrame.setLayout(new FlowLayout());
    question.setOpaque(true);
    question.setForeground(Color.blue);
    question.setBackground(Color.cyan);
    
    // question2.setFont(headLineFont2);
    // question2.setOpaque(true);
    question2.setForeground(Color.green);
    //question2.setBackground(Color.red);


    //put the label on the frame
    aFrame.add(question);
    aFrame.add(question2);
    aFrame.setVisible(true);
    aFrame.getContentPane().setBackground(Color.red);
  }
}