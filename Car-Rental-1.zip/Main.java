//David Lim
//8-26-22
//Project: Car Rental 1

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main extends  JFrame implements ActionListener{

	//declare our components or fields
	// a field is a global level variable
  double totalcost;
  double totalpeople;
  double avgcost;
	JTextField txtName = new JTextField(20);
	JTextField txtAddress = new JTextField(20);
	JTextField txtCity = new JTextField(20);
  JTextField txtState = new JTextField(20);
  JTextField txtZipcode = new JTextField(20);
  JTextField txtStartodometer = new JTextField(20);
  JTextField txtEndodometer = new JTextField(20);
  JTextField txtDays = new JTextField(20);
	//declare textArea
	JTextArea txaPayroll = new JTextArea("",10,30);
	JButton btnAdd = new JButton("Calculate");
	
	//declare variables to hold information.
  
	
	
	
	//main is the first method to run - method means function
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declare a frame for form
		Main frame = new Main();
		frame.setSize(500,500);
		frame.setVisible(true);

	}
	//declare constructor for the project
	//The constructor sets everything up.
	public Main() 
	{
		super("Button Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//set layout manager
		setLayout(new FlowLayout());
		//add our components to the form
		add(new JLabel("Name:"));
		add(txtName);
		add(new JLabel("Address:"));
		add(txtAddress);
		add(new JLabel("City:"));
		add(txtCity);
    add(new JLabel("State:"));
    add(txtState);
    add(new JLabel("Zip code:"));
    add(txtZipcode);
    add(new JLabel("Starting odometer:"));
    add(txtStartodometer);
    add(new JLabel("Ending odometer:"));
    add(txtEndodometer);
    add(new JLabel("Days Rented:"));
    add(txtDays);
		add(btnAdd);
		add(txaPayroll);
		//*********
		//add listener to the button
		btnAdd.addActionListener(this);
		
		
		
		
		
	}//end of constructor
	
	//when you push the button - the code comes here
	
	public void actionPerformed(ActionEvent event) 
	{
		Object objSource = event.getSource();
		
		if(objSource == btnAdd) 
		{
			String nameString = "";
      double startOdometer;
      double endOdometer;
      double daysRented;
      double cost;
      startOdometer = Double.parseDouble(txtStartodometer.getText());
			endOdometer = Double.parseDouble(txtEndodometer.getText());
      daysRented = Double.parseDouble(txtDays.getText());
      double miles = endOdometer - startOdometer;
      cost = payProcess(startOdometer, endOdometer, daysRented);
      totalcost+=cost;
      totalpeople++;
      avgcost = totalcost / totalpeople;
			String outputString = "";
			//get information from textboxes
			nameString = txtName.getText();
			//concatenate the text together
			outputString = "Customer Info: " + "\n" + nameString +"\t" + txtAddress.getText() + "" + txtCity.getText() + ", " + txtState.getText() + " " + txtZipcode.getText() + cost + "\n" + "Rental Details: " + "\n" + "Miles: " + miles + "\t" + "Cost: " + cost;
			//output to the text area
			txaPayroll.append(outputString);
			
			//clear text boxes
			txtName.setText("");
			txtCity.setText("");
			txtAddress.setText("");
			txtName.requestFocus();
		}
		
		
		
	}
	public double payProcess(double startmiles, double endmiles, double days){
    double cost = 0.0;
    double miles;
    miles = endmiles - startmiles;
    cost = 15 * days + miles * 0.12;
    return cost;
  }

}//end of class