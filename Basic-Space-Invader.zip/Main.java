
//Name: Mister S
//Date: 9/5/17
/*
* This project codes concatenation and how to do buttons
* and text fields
*/

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import java.awt.event.*;

public class Main extends JFrame implements KeyListener, ActionListener {

  // declare our componets or fields
  // a field is a global level variable.

  int intXAmount = 10;
  int speedX = 10;
  int speedY = 10;
  int playerX = 50;
  int playerY = 100;

  int invaderX = 200;
  int invaderY = 50;
  int invadervelX = 10;

  Timer invaderTimer = new Timer(100, this);
  boolean timerState = true;

  public Main() {

    super("Button Test");

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new FlowLayout());
    // pnlInput.setLayout(new GridLayout(0,2));
    startTheTimer();

    addKeyListener(this);

  }

  public static void main(String[] args) {

    // Place components on the applet panel
    final int FRAME_WIDTH = 500;
    final int FRAME_HEIGHT = 500;
    Main frame = new Main();
    frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
    frame.setVisible(true);

  }

  // when you push the button it comes this method
  public void actionPerformed(ActionEvent event) {

    // declare variable to hold which button is called
    Object objSource = event.getSource();

    if (timerState) {
      if (invaderX >= 500){
        invadervelX *=-1;
      }
      else if (invaderX <= 0){
        invadervelX *=-1;
      }
      invaderX += invadervelX;
    }
    requestFocus();
    repaint();

  }

  public void startTheTimer() {
    invaderTimer.start();
  }

  public void stopTheTimer() {

  }

  // create the paint method to show graphics
  public void paint(Graphics g) {

    super.paint(g);
    g.setColor(Color.red);
    g.fillRect(playerX, playerY, 50, 50);

    g.setColor(Color.blue);
    g.fillRect(invaderX, invaderY, 40, 40);

  }

  public void Update(Graphics gr) {
    // call the paint method
    paint(gr);
  }

  public void keyPressed(KeyEvent e) {

    int key = e.getKeyCode();
    // nameTextField.setText(""+ key);
    if (key == 37) {
      playerX -= speedX;
    }

    else if (key == 39) {
      playerX += speedX;
    }
    if (key == 38) {
      playerY -= speedY;
    } else if (key == 40) {
      playerY += speedY;
    }
    repaint();

  }

  public void keyReleased(KeyEvent e) {
    // nameTextField.setText("");
  }

  public void keyTyped(KeyEvent e) {

  }

}