//David Lim
//8-18-22
//Project: learning concatenation

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main extends  JFrame implements ActionListener{

	//declare our components or fields
	// a field is a global level variable
	JTextField txtName = new JTextField(20);
	JTextField txtHours = new JTextField(20);
	JTextField txtRate = new JTextField(5);
	//declare textArea
	JTextArea txaPayroll = new JTextArea("Name:   "   
		+"Pay:" + "\n",10,30);
	JButton btnAdd = new JButton("Calculate");
	
	//declare variables to hold information.
  
	
	
	
	//main is the first method to run - method means function
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declare a frame for form
		Main frame = new Main();
		frame.setSize(500,500);
		frame.setVisible(true);

	}
	//declare constructor for the project
	//The constructor sets everything up.
	public Main() 
	{
		
		super("Button Application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//set layout manager
		setLayout(new FlowLayout());
		//add our components to the form
		add(new JLabel("Name:    "));
		add(txtName);
		add(new JLabel("Hours worked:    "));
		add(txtHours);
		add(new JLabel("Rate:    "));
		add(txtRate);
		add(btnAdd);
		add(txaPayroll);
		//*********
		//add listener to the button
		btnAdd.addActionListener(this);
		
		
		
		
		
	}//end of constructor
	
	//when you push the button - the code comes here
	
	public void actionPerformed(ActionEvent event) 
	{
		Object objSource = event.getSource();
		
		if(objSource == btnAdd) 
		{
			String nameString = "";
      double rateDouble = 0;
      double hoursDouble = 0;
      double payDouble;
      
      payDouble = payProcess(hoursDouble, rateDouble);
			String outputString = "";
			//get information from textboxes
			nameString = txtName.getText();
      rateDouble = Double.parseDouble(txtRate.getText());
			hoursDouble = Double.parseDouble(txtHours.getText());
      payDouble = rateDouble * hoursDouble;
			//concatenate the text together
			outputString = nameString +"\t" + payDouble + "\n";
			//output to the text area
			txaPayroll.append(outputString);
			
			//clear text boxes
			txtName.setText("");
			txtRate.setText("");
			txtHours.setText("");
			txtName.requestFocus();
		}
		
		
		
	}
	public double payProcess(double theHours, double theRate){
    double theirPay = 0.0;
    theirPay = theHours * theRate;
    return theirPay;
  }

}//end of class