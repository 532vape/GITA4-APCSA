//this class does the bulk of calculations for the project
public class CalculationsClass{
  //declare class variables
  //private because we want them to belong only to this class
  private double dblRate, dblHours, dblPay;
  
  private static int numProcessedInt = 0;

  //create a class constructor. it's the first method/function that runs in the class. it basically just sets everything up. the constructor has the same name as the class

  CalculationsClass(double theRate, double theHours){
    dblRate = theRate;
    dblHours = theHours;
    
  }
  private void CalculatePay(){
    dblPay = dblRate * dblHours;
    numProcessedInt++;
  }
  public double getPay(){
    CalculatePay();
    return dblPay;
  }
  public int getEmployeeCount(){
    return numProcessedInt;
  }
}